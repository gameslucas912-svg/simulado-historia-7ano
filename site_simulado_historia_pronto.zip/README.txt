# Simulado de História — site pronto para publicação

## O que há aqui
- `public/index.html`: site completo, sem servidor e sem banco de dados.
- Funciona em celular e computador.
- As respostas ficam somente na sessão do navegador.
- O resultado aparece depois de clicar em FINALIZAR, mas só se as 20 questões estiverem respondidas.
- Nota de 0 a 20, erros, respostas corretas e explicações.

## Publicação
A pasta `public` pode ser publicada em serviços de hospedagem de site estático. Depois de publicada, o serviço fornece um endereço que pode ser compartilhado com os colegas.

Não é necessário instalar aplicativo nem criar banco de dados para este simulado.
